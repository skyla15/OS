#include <stdio.h>
#include <unistd.h>

int main()
{
	unlink("sample.txt");

	return 0;
}
