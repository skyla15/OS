#include <stdio.h>
#include <unistd.h>

int main()
{
	while(1)
	{
		printf("\nKILLING PROCESS\n");
		sleep(5);
	}
	return 0;
}
